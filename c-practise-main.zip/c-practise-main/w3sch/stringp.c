#include <stdio.h>

int main (void) {
    char greetings [] = "Hello World of C";
    printf("%s\n", greetings);
    return  (0);
}