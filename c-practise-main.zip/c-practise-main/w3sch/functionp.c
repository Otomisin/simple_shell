#include <stdio.h>

int main (){

    return0;
}