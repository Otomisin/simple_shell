#include <stdio.h>

int main (void)
{
    int x = 20;
    int y = 18;
    if (x > y) {
    printf("x is greater than y\n");
    };
    return (0);
}