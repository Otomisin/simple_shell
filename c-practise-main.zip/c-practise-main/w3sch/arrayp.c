#include <stdio.h>

int main (){
    int myNumber []={25,50, 75, 100};
    printf("%d\n", myNumber[1]);
    return (0);
}