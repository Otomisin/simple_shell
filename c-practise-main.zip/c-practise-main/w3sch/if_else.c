#include <stdio.h>

int main (void)

{
    int time = 20;
    if (time< 18){
        printf ("Good day.");
    } else {
        printf ("Good evening. ");
    }
    return (0);
}