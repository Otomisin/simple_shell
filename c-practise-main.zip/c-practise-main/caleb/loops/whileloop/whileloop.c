#include <stdio.h>
int main ()
{
     int i = 1;
     while (i <= 4);
     {
          printf ("%d ", i);
          i++;
     }
     return (0);
}