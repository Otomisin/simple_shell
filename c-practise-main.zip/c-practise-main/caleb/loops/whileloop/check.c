#include <stdio.h>

int main(void)
{
   int count=1;
   while (count <= 4)
   {
	printf("%d ", count);
	count++;
   }
   return 0;
}