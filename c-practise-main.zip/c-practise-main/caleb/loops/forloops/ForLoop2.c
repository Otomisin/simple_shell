#include <stdio.h>

/*
*initialization
* comparison
* upates
*/

int main(void)
{
     int num;
     scanf("%d", &num);

     int i;
     for(i = 0; i < num; i++)
     {
          printf ("%d\n", i);
     }
     printf("You printed %d numbers \n", i);
    return 0;
}

