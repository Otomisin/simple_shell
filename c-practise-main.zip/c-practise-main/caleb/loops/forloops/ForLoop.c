#include <stdio.h>

int main(void)
{

/*
*initialization
* comparison
* upates 
*/

for(int i = 4; i <= 11; i++)
     {
          printf ("%d\n", i);
     }
     return 0;
}
