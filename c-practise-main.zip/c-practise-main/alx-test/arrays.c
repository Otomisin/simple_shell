#include <stdio.h>

int main()
{
     int size = 5;
     int mygrade [] = {23, 50, 75, 100, 34};     

     for  (int i = 0; i <= size; i++)
     {
         printf("%d ",mygrade[i]);
     } 

     
     return 0;
}