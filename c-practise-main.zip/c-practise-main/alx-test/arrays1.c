#include <stdio.h>

int main()
{
     int mygrade [] = {23, 50, 75, 100,};
     printf("%d ",mygrade[0]);

     // index = 0 based number
     // element =
     // size =
     return 0;
}