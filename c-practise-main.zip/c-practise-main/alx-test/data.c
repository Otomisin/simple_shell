#include <stdio.h>

int main()
{
	int a = 9;
	int b = -9;
	int c = 89U;
	long int d = 99998L;

	printf("Integer value with postive data: %d\n", a);
	printf("Integer value with negative data: %d\n", b);
	printf("integer value with negative value: %u\n", c);
	printf("integer value with a long int data: %ld\n", d);

	return 0;

}
