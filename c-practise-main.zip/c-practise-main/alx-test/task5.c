#include <stdio.h>
/**
 * main - print if the number is postive, zero, or negative
 *
 * Description: using the main function
 * this program prints "Programming is positive, zero, or negative
 * Return: 0
 */
int main(void)
{
int i;
for (i = 0 ; i < 10; i++)
{
	printf ("%i", i);
}
printf("\n");
return (0);
}